fftrec = abs(fft(rec, 512));
plot(1:512, fftrec);