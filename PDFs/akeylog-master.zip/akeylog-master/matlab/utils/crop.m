[M I] = max(rec);
rec = rec(I:I+6000);
plot(rec);